from typeguard import typechecked
from ..models.error_models import GuideCountErrorType, GuideCountError
from ..models.quality_control_models import SingleInferenceQualityControlResult, MatchSetSingleInferenceQualityControlResult, QualityControlResult
from ..models.mapping_models import GeneralMappingInferenceDict
from typing import DefaultDict, Tuple, Optional, Union
from collections import defaultdict
from ..processing.crispr_editing_processing import get_non_error_dict

#
# PERFORM THE QC (multi-level, optimized, sample-agnostic)
#
def perform_counts_quality_control(
    observed_guide_reporter_umi_counts_inferred: Union[GeneralMappingInferenceDict, DefaultDict[str, GeneralMappingInferenceDict]],
    contains_guide_umi: bool,
    contains_guide_surrogate: bool,
    contains_guide_barcode: bool,
    contains_sample_barcode: bool,
):
    # ---------- Helpers ----------
    def get_umi_noncollapsed_counts(d):
        return sum(sum(v.observed_value.values()) for v in d.values())

    def get_umi_collapsed_counts(d):
        return sum(len(v.observed_value.values()) for v in d.values())

    def get_counts(d):
        return sum(v.observed_value for v in d.values())

    def get_non_error_dict(obs_dict, attribute_name: str):
        """Extract subdict of entries without match errors."""
        return {
            k: v
            for k, v in obs_dict.items()
            if getattr(v.inferred_value, attribute_name) is not None
            and getattr(v.inferred_value, attribute_name).error is None
        }

    # ---------- Base QC Structure ----------
    qc_results: DefaultDict[str, MatchSetSingleInferenceQualityControlResult] = defaultdict(MatchSetSingleInferenceQualityControlResult)

    # ---------- Shared Total Counts (computed once) ----------
    if contains_guide_umi:
        total_noncollapsed = get_umi_noncollapsed_counts(observed_guide_reporter_umi_counts_inferred)
        total_collapsed = get_umi_collapsed_counts(observed_guide_reporter_umi_counts_inferred)
    else:
        total_counts = get_counts(observed_guide_reporter_umi_counts_inferred)

    # ---------- Helper Subfunctions ----------
    def set_num_non_error_counts(qc_result, subdict):
        if contains_guide_umi:
            qc_result.num_non_error_umi_noncollapsed_counts = get_umi_noncollapsed_counts(subdict)
            qc_result.num_non_error_umi_collapsed_counts = get_umi_collapsed_counts(subdict)
            qc_result.num_total_umi_noncollapsed_counts = total_noncollapsed
            qc_result.num_total_umi_collapsed_counts = total_collapsed
        else:
            qc_result.num_non_error_counts = get_counts(subdict)
            qc_result.num_total_counts = total_counts
        return qc_result


    def set_num_guide_count_error_types(qc_result, attribute_name: str):
        guide_count_error_type_umi_noncollapsed_count: DefaultDict[GuideCountErrorType, int] = defaultdict(int)
        guide_count_error_type_umi_collapsed_count: DefaultDict[GuideCountErrorType, int] = defaultdict(int)
        guide_count_error_type_count: DefaultDict[GuideCountErrorType, int] = defaultdict(int)

        for _, obs_value in observed_guide_reporter_umi_counts_inferred.items():
            attr = getattr(obs_value.inferred_value, attribute_name, None)
            error = getattr(attr, "error", None) if attr is not None else None

            if error is None:
                continue  # skip entries without an error

            if contains_guide_umi:
                guide_count_error_type_umi_noncollapsed_count[error.guide_count_error_type] += sum(obs_value.observed_value.values())
                guide_count_error_type_umi_collapsed_count[error.guide_count_error_type] += len(obs_value.observed_value)
            else:
                guide_count_error_type_count[error.guide_count_error_type] += obs_value.observed_value

        qc_result.guide_count_error_type_umi_noncollapsed_count = guide_count_error_type_umi_noncollapsed_count
        qc_result.guide_count_error_type_umi_collapsed_count = guide_count_error_type_umi_collapsed_count
        qc_result.guide_count_error_type_count = guide_count_error_type_count
        return qc_result

    # ---------- Main Routine ----------
    def process_attribute(attribute_name: str):
        subdict = get_non_error_dict(observed_guide_reporter_umi_counts_inferred, attribute_name)
        qc = MatchSetSingleInferenceQualityControlResult()
        qc.non_error_dict = subdict
        qc = set_num_non_error_counts(qc, subdict)
        qc = set_num_guide_count_error_types(qc, attribute_name)
        qc_results[attribute_name] = qc

    # Always include these
    process_attribute("protospacer_match")

    if contains_guide_barcode:
        process_attribute("protospacer_match_barcode_match")
        if contains_guide_surrogate:
            process_attribute("protospacer_match_surrogate_match_barcode_match")
            process_attribute("protospacer_mismatch_surrogate_match_barcode_match")

    if contains_guide_surrogate:
        process_attribute("protospacer_match_surrogate_match")
        process_attribute("protospacer_mismatch_surrogate_match")

    # ---------- Wrap into the final container ----------
    quality_control_result = QualityControlResult()
    for key, value in qc_results.items():
        setattr(quality_control_result, key, value)

    return quality_control_result