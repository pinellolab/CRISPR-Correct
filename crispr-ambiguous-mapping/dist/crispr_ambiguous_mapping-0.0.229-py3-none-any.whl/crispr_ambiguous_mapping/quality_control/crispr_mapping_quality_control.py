from typeguard import typechecked
from ..models.error_models import GuideCountErrorType, GuideCountError
from ..models.quality_control_models import SingleInferenceQualityControlResult, MatchSetSingleInferenceQualityControlResult, QualityControlResult
from ..models.mapping_models import GeneralMappingInferenceDict
from typing import DefaultDict, Tuple, Optional, Union
from collections import defaultdict
from ..processing.crispr_editing_processing import get_non_error_dict

#
# PERFORM THE QC
#
def perform_counts_quality_control(
    observed_guide_reporter_umi_counts_inferred: Union[GeneralMappingInferenceDict, DefaultDict[str, GeneralMappingInferenceDict]],
    contains_guide_umi: bool,
    contains_guide_surrogate: bool,
    contains_guide_barcode: bool,
    contains_sample_barcode: bool
):
    # ---------- Helper functions for counts ----------
    def iter_all_obs_values(d):
        """Flatten observed values for both sample-barcode and no-sample-barcode cases"""
        if contains_sample_barcode:
            for sample_dict in d.values():
                for obs_value in sample_dict.values():
                    yield obs_value
        else:
            for obs_value in d.values():
                yield obs_value

    def get_umi_noncollapsed_counts(d):
        return sum(
            sum(v.observed_value.values()) if contains_guide_umi else v.observed_value
            for v in iter_all_obs_values(d)
        )

    def get_umi_collapsed_counts(d):
        return sum(
            len(v.observed_value) if contains_guide_umi else 1
            for v in iter_all_obs_values(d)
        )

    def get_counts(d):
        return sum(v.observed_value for v in iter_all_obs_values(d))

    # ---------- Helper to set non-error counts ----------
    @typechecked
    def set_num_non_error_counts(qc_result: SingleInferenceQualityControlResult, counts_inferred_dict: dict) -> SingleInferenceQualityControlResult:
        if contains_guide_umi:
            qc_result.num_non_error_umi_noncollapsed_counts = get_umi_noncollapsed_counts(counts_inferred_dict)
            qc_result.num_non_error_umi_collapsed_counts = get_umi_collapsed_counts(counts_inferred_dict)
            qc_result.num_total_umi_noncollapsed_counts = get_umi_noncollapsed_counts(observed_guide_reporter_umi_counts_inferred)
            qc_result.num_total_umi_collapsed_counts = get_umi_collapsed_counts(observed_guide_reporter_umi_counts_inferred)
        else:
            qc_result.num_non_error_counts = get_counts(counts_inferred_dict)
            qc_result.num_total_counts = get_counts(observed_guide_reporter_umi_counts_inferred)
        return qc_result

    # ---------- Helper to set guide count error types ----------
    @typechecked
    def set_num_guide_count_error_types(qc_result: SingleInferenceQualityControlResult, attribute_name: str) -> SingleInferenceQualityControlResult:
        guide_count_error_type_umi_noncollapsed_count: DefaultDict[GuideCountErrorType, int] = defaultdict(int)
        guide_count_error_type_umi_collapsed_count: DefaultDict[GuideCountErrorType, int] = defaultdict(int)
        guide_count_error_type_count: DefaultDict[GuideCountErrorType, int] = defaultdict(int)

        for obs_value in iter_all_obs_values(observed_guide_reporter_umi_counts_inferred):
            attr = getattr(obs_value.inferred_value, attribute_name, None)
            error = getattr(attr, "error", None)
            if error is not None:  # only count actual errors
                if contains_guide_umi:
                    guide_count_error_type_umi_noncollapsed_count[error.guide_count_error_type] += sum(obs_value.observed_value.values())
                    guide_count_error_type_umi_collapsed_count[error.guide_count_error_type] += len(obs_value.observed_value)
                else:
                    guide_count_error_type_count[error.guide_count_error_type] += obs_value.observed_value

        qc_result.guide_count_error_type_umi_noncollapsed_count = guide_count_error_type_umi_noncollapsed_count
        qc_result.guide_count_error_type_umi_collapsed_count = guide_count_error_type_umi_collapsed_count
        qc_result.guide_count_error_type_count = guide_count_error_type_count
        return qc_result

    # ---------- Generate QC for a single attribute ----------
    @typechecked
    def set_match_set_single_inference_quality_control_results(attribute_name: str) -> MatchSetSingleInferenceQualityControlResult:
        qc = MatchSetSingleInferenceQualityControlResult()
        qc.non_error_dict = get_non_error_dict(observed_guide_reporter_umi_counts_inferred, attribute_name)
        qc = set_num_non_error_counts(qc, qc.non_error_dict)
        qc = set_num_guide_count_error_types(qc, attribute_name)
        return qc

    # ---------- Main QC result ----------
    qc_results = QualityControlResult()
    qc_results.protospacer_match = set_match_set_single_inference_quality_control_results("protospacer_match")
    
    if contains_guide_barcode:
        qc_results.protospacer_match_barcode_match = set_match_set_single_inference_quality_control_results("protospacer_match_barcode_match")
        if contains_guide_surrogate:
            qc_results.protospacer_match_surrogate_match_barcode_match = set_match_set_single_inference_quality_control_results("protospacer_match_surrogate_match_barcode_match")
            qc_results.protospacer_mismatch_surrogate_match_barcode_match = set_match_set_single_inference_quality_control_results("protospacer_mismatch_surrogate_match_barcode_match")
    
    if contains_guide_surrogate:
        qc_results.protospacer_match_surrogate_match = set_match_set_single_inference_quality_control_results("protospacer_match_surrogate_match")
        qc_results.protospacer_mismatch_surrogate_match = set_match_set_single_inference_quality_control_results("protospacer_mismatch_surrogate_match")

    return qc_results
