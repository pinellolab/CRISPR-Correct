#!/usr/bin/env python

from .framework.CrisprAmbiguousMapping import *
